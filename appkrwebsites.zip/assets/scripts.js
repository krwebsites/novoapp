function salvar()
{

	var storage = window.localStorage;
	//pegar o titulo e o conteudo preenchido
	var titulo = document.getElementById('titulo');
	var conteudo = document.getElementById('conteudo');
	var key = createKey();


	//criar um array para salvar titulo e conteudo da nota
	var nota = [titulo.value, conteudo.value];


	//localStorage não suporta salvar "arrays", então é necessário
	//transformar o "array" "nota" em String.
	storage.setItem(key, JSON.stringify(nota));

	console.log("Nota "+ key + "(" + titulo.value + ") salvo");

	//limpar os campos
	titulo.value = '';
	conteudo.value = '';

	//chama a funcao "listar" para exibir as notas atualizadas
	listar();

}

	function listar()

	{
		//pegar todas as notas (pelas chaves do array localStorage)
		var storage = window.localStorage;
		var keys = Object.keys(storage);

		//pego o elemento "listaNotas"
		var listaNotas = document.getElementById('listaNotas');
		//antes de lista as notas é preciso limpar a "ul" para 
		//evitar valores duplicados.
		listaNotas.innerHTML = '';


		//percorro as chaves do storage e pego as notas salvas
		for(var key of keys) {

			// nota[0] --> titulo
			// nota[1] --> conteudo
			var nota = JSON.parse(storage.getItem(key));
			//crio um elemento "li" para inserir no "listaNovas"

			var li = document.createElement('li');
			var a = document.createElement('a');

			//insiro o elemento "a" dentro do elemento "li"
			li.appendChild(a);
			a.innerText = nota[0]; //titulo

			//insiro o elemento "li" dentro do elemento "listaNotas"
			listaNotas.appendChild(li);
			//temos que chamar a função "jquery" listview para dar
			//"refresh" na div.
			$('#listaNotas').listview('refresh'); 

		}


	}


function createKey()
{
	var date = new Date();
	return date.getFullYear().toString() + date.getMonth().toString() + 
	+ date.getDate().toString() + date.getHours().toString() + 
	+ date.getMinutes().toString() + date.getSeconds().toString();

	//Ex: 2021622151432

}


window.onload = function(){
	//executar aqui quando todos os elementos da página forem carregadas
	//quando executar exibe as notas cadastradas anteriormente
	listar();
	//evento de click no btnSalvar
	var btnSalvar = document.getElementById('btnSalvar');
	btnSalvar.addEventListener('click', salvar);

}